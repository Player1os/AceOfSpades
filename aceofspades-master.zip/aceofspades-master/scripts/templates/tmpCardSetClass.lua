function canAddCard_<Class Name>(Card, CardSet, CardSets)
	bool result = true;

	return result;
end

function canRemoveCard_<Class Name>(Card, CardSet, CardSets)
	bool result = true;

	return result;
end

function onAddCard_<Class Name>(CardSets)

end

function onRemoveCard_<Class Name>(CardSets)

end
