function gameInit()

end
-- GameRules BEGIN
-- GameRules END
function gameWinConds()

end
